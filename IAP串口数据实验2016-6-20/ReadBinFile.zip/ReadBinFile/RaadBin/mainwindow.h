#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QFile>
#include <QDialog>
#include "crc_cal.h"
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QtCore>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    struct Settings {
        QString name;
        qint32  baudRate;
        QSerialPort::DataBits dataBits;
        QSerialPort::Parity   parity;           //校验
        QSerialPort::StopBits stopBits;
        QSerialPort::FlowControl flow;
    };
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_fileButton_clicked();
    void on_viewButton_clicked();
    void on_loadButton_clicked();
    void transmitDataFun(int cnt);             //发送文件
//    void FillSendData(QByteArray*pDestData,QByteArray*pReadBin,quint64 num); //填充发送的数据帧
    void on_pushButton_clicked();

    void on_openButton_clicked();
    void readData(void);
    void on_sendButton_clicked();
    void timerUpDate();

    void on_loadButton_2_clicked();

signals:
    void transmitData(int);
    void binFileOpenFailed(void);
    void binFileLook(void);
private:
    Ui::MainWindow *ui;

    QString fileLocation;
    quint64 binSize;
    QFile *binFile;
    qint64 binLoadCnt;  //记录下载了多少K
    qint64 SendErrorCounter;
    QByteArray usart_temp;
    CRC_Cal crc;

    //QSerialPort *serial;

    QSerialPort serial;//
    bool OpenStatus;

    Settings currentSettings;

};

#endif // MAINWINDOW_H
