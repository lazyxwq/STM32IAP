#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QLineEdit>
#include <QFileDialog>
#include <QDEBUG>
#include <QListWidgetItem>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QTimer *timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(timerUpDate()));
    connect (this, SIGNAL(binFileOpenFailed()), this, SLOT(on_fileButton_clicked()));
    connect (this, SIGNAL(binFileLook()), this, SLOT(on_viewButton_clicked()));
    connect (this, SIGNAL(transmitData(int)), this, SLOT(transmitDataFun(int)));
    connect (&serial, SIGNAL(readyRead()), this, SLOT(readData()));
    timer->start(1000);
}
void MainWindow::readData ()
{

     //usart_temp=serial.read(1);//在缓冲区中读一个byte
     usart_temp += serial.readAll ();       //存储收到数据
     ui->binTextEdit->insertPlainText(tr(usart_temp));


     qDebug()<<"单片机应答数据为:"<<tr(usart_temp);


     if(usart_temp == "Ready\r\n")
     {
        emit transmitData (0);      //发送首K内容
        ui->binTextEdit->insertPlainText (tr("\n成功写入1K,总共写入%1K\n").arg (binLoadCnt));

        qDebug()<<"收到单片机应答数据:Ready"<<endl;
        usart_temp.clear ();
     }

    else if(usart_temp == "Next\r\n")
    {
            emit transmitData(binLoadCnt++);        //发送写入完成信号
            ui->binTextEdit->insertPlainText (tr("\n成功写入1K,总共写入%1K\n").arg (binLoadCnt));
            usart_temp.clear ();
            SendErrorCounter=0;
    }
    else  if(usart_temp == "OK\r\n")
    {
        ui->binTextEdit->insertPlainText (tr("\nIAP结束\n"));
        usart_temp.clear ();
    }
    else if(usart_temp == "again\r\n")
    {              
        ui->binTextEdit->insertPlainText (tr("\n未成功写入!正在尝试重新写入...\n"));
        usart_temp.clear ();
        if(SendErrorCounter>=5)
        {
            ui->binTextEdit->insertPlainText (tr("\n累计重新写入%次失败！\n").arg (SendErrorCounter));
            //带添加
            SendErrorCounter=0;
        }
            emit transmitData (binLoadCnt-1);//
            SendErrorCounter++;
    }
    else
        usart_temp.clear ();
}
void MainWindow::timerUpDate()
{
//    qDebug()<<"秒计算器当前值为："<<Second<<endl;
    QDateTime time = QDateTime::currentDateTime();
    QString str = time.toString("yyyy-MM-dd hh:mm:ss dddd");
    ui->currentTime->setText(str);
}

void MainWindow::transmitDataFun (int cnt)             //发送文件
{

    qint16 temp = 0;            //剩余待传数据
    qint16 FileSendEndFg;


    QFile *binFile = new QFile(fileLocation);
    binFile->open (QIODevice::ReadOnly);
    binFile->seek (cnt * 1024);

    qDebug()<<"正在第"<<cnt+1<<"次发送数据给单片机"<<endl;
    ui->loadButton->setEnabled (false);

    char * binByte = new char[1024];//bin缓存
    memset (binByte, 0xff, 1024);

    //data_len_L  data_len_H  data(no more than 1K)   index_L index_H CRC

    QByteArray binTransmit;
    binTransmit.resize (8);

    temp = binSize - 1024*cnt;
    qDebug()<<"剩余文件大小："<<temp<<endl;
    if(temp < 1024)
    {
        if(temp>0)//数据大于0
        {
            binTransmit[0] = temp % 256;
            binTransmit[1] = temp / 256;
            //index CRC 暂空
            binTransmit[2] = cnt % 256;
            binTransmit[3] = cnt / 256;

            binTransmit[4] = 0xff;
            binTransmit[5] = 0xff;
            binTransmit[6] = 0xff;
            binTransmit[7] = 0xff;

            binFile->read (binByte, temp);
            binTransmit.insert(2, binByte, 1024);

            crc.crc32 (&binTransmit, binTransmit.size () - 4);

            unsigned int crc_val = crc.getCrc32 ();
            qDebug("CRC(32bit):%X",crc_val);
            binTransmit[1024 + 4] = crc_val;
            binTransmit[1024 + 5] = crc_val >> 8;
            binTransmit[1024 + 6] = crc_val >> 16;
            binTransmit[1024 + 7] = crc_val >> 24;
        }
        ui->loadProgressBar->setValue (100);
        ui->loadButton->setEnabled (true);
        FileSendEndFg=1;
    }
    else
    {

        binTransmit[0] = 0x00;//发送1K数据
        binTransmit[1] = 0x04;
        //index CRC 暂空
        binTransmit[2] = cnt % 256;     //L
        binTransmit[3] = cnt / 256;     //H
        binTransmit[4] = 0xff;          //L
        binTransmit[5] = 0xff;
        binTransmit[6] = 0xff;
        binTransmit[7] = 0xff;          //H

        binFile->read (binByte, 1024);
        binTransmit.insert(2, binByte, 1024);

        crc.crc32 (&binTransmit, binTransmit.size () - 4);
        unsigned int crc_val = crc.getCrc32 ();
        qDebug("CRC(32bit):%X",crc_val);
        binTransmit[1024 + 4] = crc_val;
        binTransmit[1024 + 5] = crc_val >> 8;
        binTransmit[1024 + 6] = crc_val >> 16;
        binTransmit[1024 + 7] = crc_val >> 24;


        int i = (1 - float(temp) / float(binSize)) * 100;
        ui->loadProgressBar->setValue (i);
        FileSendEndFg=0;
    }

    delete binByte;
    if(temp>0)//数据大于0
      {
         serial.write(binTransmit);//数据与后面命令打包一起发送了，所以下位机需要解析2针数据
         qDebug()<<"一次1K数据发送完毕："<<endl;
      }
    if(FileSendEndFg)
     serial.write ("FileEnd");
    else
    serial.write ("OnceEnd");

}
MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_fileButton_clicked()
{
        fileLocation = QFileDialog::getOpenFileName (this, tr("Open File"),
                                                     fileLocation, tr("文件 (*.bin)"));
        ui->fileEdit->setText (fileLocation);
        if(fileLocation != NULL)
        {
            QFileInfo *temp = new QFileInfo(fileLocation);
            binSize = temp->size ();

            QFile *binFile = new QFile(fileLocation);
            if(!binFile->open (QIODevice::ReadOnly))emit binFileOpenFailed ();  //重新打开文件
            else
            {
                binFile->close ();
            }
            delete binFile;

            ui->binTextEdit->clear ();
            emit binFileLook();
            delete temp;
        }

}
void MainWindow::on_viewButton_clicked()            //查看bin内容
{
    QFile *binFile = new QFile(fileLocation);
    if(!binFile->open (QIODevice::ReadOnly))emit binFileOpenFailed ();  //重新打开文件
   // else ui->tabWidget->setCurrentIndex (1);

    QDataStream in(binFile);
    char * binByte = new char[binSize];
    in.setVersion (QDataStream::Qt_4_0);

    in.readRawData (binByte, binSize);      //读出文件到缓存

    QByteArray *tempByte = new QByteArray(binByte, binSize);                //格式转换
    delete[] binByte;
    QString *tempStr = new QString(tempByte->toHex ().toUpper ());
    delete tempByte;
    //显示文件内容
    qint8 cnt = 1;
    qint16 kcnt = 0;
    for(qint64 i = 2; i < tempStr->size ();)
    {
        tempStr->insert (i, ' ');//每个字节之间空一格
        i += 3;
        cnt++;
        if(cnt == 8)//每8个字节空2格
        {
            tempStr->insert (i, ' ');
            i += 1;
        }
        if(cnt == 16)//每16个字节空一格
        {
            cnt = 1;
            kcnt ++;
            if(kcnt == 64)//每64行，即1K数据，空一行
            {
                kcnt = 0;
                tempStr->insert (i, '\n');
                i++;
            }
            tempStr->insert (i, '\n');
            i += 3;         //避免换行后开头一个空格,换行相当于从新插入
        }

    }
    ui->binTextEdit->insertPlainText (*tempStr);

    delete tempStr;

    binFile->close ();
    delete binFile;
}

void MainWindow::on_pushButton_clicked()
{
     ui->binTextEdit->clear ();
     ui->loadProgressBar->setValue (0);
}

 void MainWindow::on_openButton_clicked()
 {
     qDebug()<<"Enter Opening......"<<endl;

     currentSettings.name = ui->portNameComboBox->currentText ();//获取端口号

     if(ui->baudRateComboBox->currentText()==tr("9600"))
         currentSettings.baudRate =serial.Baud9600;
     //serial->setBaudRate(QSerialPort::Baud9600,QSerialPort::AllDirections);//
     else if(ui->baudRateComboBox->currentText()==tr("115200"))
         currentSettings.baudRate = serial.Baud115200;

     if(ui->dataBitsComboBox->currentText()==tr("8"))
         currentSettings.dataBits=serial.Data8;
     else if(ui->dataBitsComboBox->currentText()==tr("7"))
         currentSettings.dataBits=serial.Data7;

     if(ui->parityComboBox->currentText()==tr("无"))
         currentSettings.parity=serial.NoParity;
     else if(ui->parityComboBox->currentText()==tr("奇"))
         currentSettings.parity=serial.OddParity;
     else if(ui->parityComboBox->currentText()==tr("偶"))
         currentSettings.parity=serial.EvenParity;

     if(ui->stopBitsComboBox->currentText()==tr("1"))
        currentSettings.stopBits =serial.OneStop;
     else if(ui->stopBitsComboBox->currentText()==tr("2"))
        currentSettings.stopBits =serial.TwoStop;

        currentSettings.flow=serial.NoFlowControl;
        qDebug()<<"Config end......"<<endl;
     if(!OpenStatus)
     {
          qDebug()<<"OK......"<<endl;
         serial.setPortName(currentSettings.name);//
         serial.close();//防止其它软件占用
         if(serial.open(QIODevice::ReadWrite))
         {
            qDebug()<<"OK 1......"<<endl;
          if( serial.setBaudRate(currentSettings.baudRate,QSerialPort::AllDirections)
                  &&serial.setDataBits (currentSettings.dataBits)
                  &&serial.setStopBits (currentSettings.stopBits)
                  &&serial.setParity   (currentSettings.parity)
                  &&serial.setFlowControl(currentSettings.flow))

             {
                qDebug()<<"OK 3......"<<endl;
                 OpenStatus = true;
                 ui->loadButton->setEnabled (true);
                 ui->baudRateComboBox->setEnabled(false);
                 ui->dataBitsComboBox->setEnabled(false);
                 ui->parityComboBox->setEnabled(false);
                 ui->stopBitsComboBox->setEnabled(false);
                 ui->portNameComboBox->setEnabled(false);
                 ui->FlowComboBox->setEnabled(false);
                 ui->openButton->setText (tr("关闭串口"));
             }

             else
             {
                qDebug()<<"OK 4......"<<endl;
                 serial.close ();
                 ui->loadButton->setEnabled (false);
                 OpenStatus = false;
                 ui->openButton->setText (tr("打开串口"));

             }
         }
         else
         {
             qDebug()<<"OK 2......"<<endl;
             OpenStatus = false;
             ui->loadButton->setEnabled (false);
             ui->openButton->setText (tr("打开串口"));
             serial.close ();
         }
     }
     else
     {
         qDebug()<<"Close Serial Port"<<endl;
         OpenStatus = false;
         ui->loadButton->setEnabled (false);
         ui->openButton->setText (tr("打开串口"));
         ui->baudRateComboBox->setEnabled(true);
         ui->dataBitsComboBox->setEnabled(true);
         ui->parityComboBox->setEnabled(true);
         ui->stopBitsComboBox->setEnabled(true);
         ui->portNameComboBox->setEnabled(true);
         ui->FlowComboBox->setEnabled(true);
         ui->loadButton->setEnabled (true);
         ui->loadProgressBar->setValue (0);
         serial.close ();
     }

 }


void MainWindow::on_sendButton_clicked()
{
//    qDebug() << "really write: "<<myCom->bytesToWrite()<<"bytes";
    serial.write(ui->sendTextEdit->toPlainText().toLatin1());
}
void MainWindow::on_loadButton_clicked()
{
        //ui->tabWidget->setCurrentIndex (0);

        ui->binTextEdit->clear ();
        ui->binTextEdit->insertPlainText (tr("正在下载APP1固件程序......\n"));
        if(binSize < 1024)
        {
             ui->binTextEdit->insertPlainText (tr("文件大小: %1 B").arg (binSize));
        }
        else if(binSize < 1024 * 1024)
            ui->binTextEdit->insertPlainText (tr("文件大小: %1 K %2 B").arg (binSize / 1024).arg (binSize % 1024));
        else
            ui->binTextEdit->insertPlainText(tr("文件大小: %1 M %2 K").arg (binSize / 1024 / 1024).arg (binSize / 1024 %1024));
        binLoadCnt = 1;         //初始化 文件偏移值 binLoadCnt*1024

        qDebug()<<"Start sending......"<<endl;
        serial.write ("update1;");//



}
void MainWindow::on_loadButton_2_clicked()
{
    ui->binTextEdit->clear ();
    ui->binTextEdit->insertPlainText (tr("正在下载APP2固件程序......\n"));
    if(binSize < 1024)
    {
         ui->binTextEdit->insertPlainText (tr("文件大小: %1 B").arg (binSize));
    }
    else if(binSize < 1024 * 1024)
        ui->binTextEdit->insertPlainText (tr("文件大小: %1 K %2 B").arg (binSize / 1024).arg (binSize % 1024));
    else
        ui->binTextEdit->insertPlainText(tr("文件大小: %1 M %2 K").arg (binSize / 1024 / 1024).arg (binSize / 1024 %1024));
    binLoadCnt = 1;         //初始化 文件偏移值 binLoadCnt*1024

    qDebug()<<"Start sending......"<<endl;
    serial.write ("update2;");//
}
