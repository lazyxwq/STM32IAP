/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QPushButton *fileButton;
    QLineEdit *fileEdit;
    QTextEdit *binTextEdit;
    QPushButton *loadButton;
    QProgressBar *loadProgressBar;
    QPushButton *pushButton;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QComboBox *portNameComboBox;
    QComboBox *baudRateComboBox;
    QComboBox *dataBitsComboBox;
    QComboBox *stopBitsComboBox;
    QComboBox *parityComboBox;
    QPushButton *openButton;
    QLabel *label_6;
    QComboBox *FlowComboBox;
    QTextEdit *sendTextEdit;
    QPushButton *sendButton;
    QLabel *currentTime;
    QPushButton *loadButton_2;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(745, 478);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        fileButton = new QPushButton(centralWidget);
        fileButton->setObjectName(QStringLiteral("fileButton"));
        fileButton->setGeometry(QRect(0, 210, 81, 23));
        fileEdit = new QLineEdit(centralWidget);
        fileEdit->setObjectName(QStringLiteral("fileEdit"));
        fileEdit->setGeometry(QRect(100, 210, 241, 20));
        binTextEdit = new QTextEdit(centralWidget);
        binTextEdit->setObjectName(QStringLiteral("binTextEdit"));
        binTextEdit->setGeometry(QRect(0, 0, 551, 171));
        loadButton = new QPushButton(centralWidget);
        loadButton->setObjectName(QStringLiteral("loadButton"));
        loadButton->setGeometry(QRect(360, 210, 75, 23));
        loadProgressBar = new QProgressBar(centralWidget);
        loadProgressBar->setObjectName(QStringLiteral("loadProgressBar"));
        loadProgressBar->setGeometry(QRect(10, 180, 551, 23));
        loadProgressBar->setValue(0);
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(450, 210, 75, 23));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 240, 41, 16));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(10, 270, 54, 12));
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(10, 300, 54, 12));
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(10, 330, 54, 12));
        label_5 = new QLabel(centralWidget);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(10, 360, 54, 12));
        portNameComboBox = new QComboBox(centralWidget);
        portNameComboBox->setObjectName(QStringLiteral("portNameComboBox"));
        portNameComboBox->setGeometry(QRect(100, 240, 69, 22));
        portNameComboBox->setEditable(false);
        baudRateComboBox = new QComboBox(centralWidget);
        baudRateComboBox->setObjectName(QStringLiteral("baudRateComboBox"));
        baudRateComboBox->setGeometry(QRect(100, 270, 69, 22));
        dataBitsComboBox = new QComboBox(centralWidget);
        dataBitsComboBox->setObjectName(QStringLiteral("dataBitsComboBox"));
        dataBitsComboBox->setGeometry(QRect(100, 300, 69, 22));
        stopBitsComboBox = new QComboBox(centralWidget);
        stopBitsComboBox->setObjectName(QStringLiteral("stopBitsComboBox"));
        stopBitsComboBox->setGeometry(QRect(100, 330, 69, 22));
        parityComboBox = new QComboBox(centralWidget);
        parityComboBox->setObjectName(QStringLiteral("parityComboBox"));
        parityComboBox->setGeometry(QRect(100, 360, 69, 22));
        openButton = new QPushButton(centralWidget);
        openButton->setObjectName(QStringLiteral("openButton"));
        openButton->setGeometry(QRect(200, 240, 75, 23));
        label_6 = new QLabel(centralWidget);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(10, 390, 54, 12));
        FlowComboBox = new QComboBox(centralWidget);
        FlowComboBox->setObjectName(QStringLiteral("FlowComboBox"));
        FlowComboBox->setGeometry(QRect(100, 390, 74, 20));
        sendTextEdit = new QTextEdit(centralWidget);
        sendTextEdit->setObjectName(QStringLiteral("sendTextEdit"));
        sendTextEdit->setGeometry(QRect(210, 280, 341, 101));
        sendButton = new QPushButton(centralWidget);
        sendButton->setObjectName(QStringLiteral("sendButton"));
        sendButton->setGeometry(QRect(210, 390, 75, 23));
        currentTime = new QLabel(centralWidget);
        currentTime->setObjectName(QStringLiteral("currentTime"));
        currentTime->setGeometry(QRect(573, 10, 161, 20));
        loadButton_2 = new QPushButton(centralWidget);
        loadButton_2->setObjectName(QStringLiteral("loadButton_2"));
        loadButton_2->setGeometry(QRect(360, 240, 75, 23));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 745, 23));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        fileButton->setText(QApplication::translate("MainWindow", "\346\211\223\345\274\200\346\226\207\344\273\266", 0));
        fileEdit->setText(QApplication::translate("MainWindow", "\346\226\207\344\273\266\345\220\215", 0));
        loadButton->setText(QApplication::translate("MainWindow", "IAP\344\270\213\350\275\2751", 0));
        pushButton->setText(QApplication::translate("MainWindow", "\346\270\205\351\231\244\347\252\227\345\217\243", 0));
        label->setText(QApplication::translate("MainWindow", "\344\270\262\345\217\243\345\217\267", 0));
        label_2->setText(QApplication::translate("MainWindow", "\346\263\242\347\211\271\347\216\207", 0));
        label_3->setText(QApplication::translate("MainWindow", "\346\225\260\346\215\256\344\275\215", 0));
        label_4->setText(QApplication::translate("MainWindow", "\345\201\234\346\255\242\344\275\215", 0));
        label_5->setText(QApplication::translate("MainWindow", "\346\240\241\351\252\214\344\275\215", 0));
        portNameComboBox->clear();
        portNameComboBox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "COM1", 0)
         << QApplication::translate("MainWindow", "COM2", 0)
         << QApplication::translate("MainWindow", "COM3", 0)
        );
        baudRateComboBox->clear();
        baudRateComboBox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "9600", 0)
         << QApplication::translate("MainWindow", "115200", 0)
        );
        dataBitsComboBox->clear();
        dataBitsComboBox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "8", 0)
         << QApplication::translate("MainWindow", "7", 0)
        );
        stopBitsComboBox->clear();
        stopBitsComboBox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "1", 0)
         << QApplication::translate("MainWindow", "2", 0)
        );
        parityComboBox->clear();
        parityComboBox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "\346\227\240", 0)
         << QApplication::translate("MainWindow", "\345\245\207", 0)
         << QApplication::translate("MainWindow", "\345\201\266", 0)
        );
        openButton->setText(QApplication::translate("MainWindow", "\346\211\223\345\274\200\344\270\262\345\217\243", 0));
        label_6->setText(QApplication::translate("MainWindow", "\346\265\201\346\216\247\345\210\266", 0));
        FlowComboBox->clear();
        FlowComboBox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "None", 0)
         << QApplication::translate("MainWindow", "HardWare", 0)
         << QApplication::translate("MainWindow", "SoftWare", 0)
         << QApplication::translate("MainWindow", "Custom", 0)
        );
        sendButton->setText(QApplication::translate("MainWindow", "\345\217\221\351\200\201", 0));
        currentTime->setText(QApplication::translate("MainWindow", "TextLabel", 0));
        loadButton_2->setText(QApplication::translate("MainWindow", "IAP\344\270\213\350\275\2752", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
