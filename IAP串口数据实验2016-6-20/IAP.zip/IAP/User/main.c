/*********************************************************************************
* 	Ӳ��ƽ̨:ԭ��ս��V1.8
*   keil�汾  keill 5.14.0.0
* 	��оƬ:STM32F103ZET6
* 	��ע������1��ӳ�䵽PB6��PB7
*********************************************************************************/
#include <stm32f10x.h>                 
#include <stdio.h>
#include "led.h"
#include "iap.h"

extern void InitializeUsart(void) ;
extern void UsartSystick1000Service(void) ;

uint8_t step=0;
/*******************************************************************************
* ������	  : TimerSystick10Routine  
* ����	    : IAP���г���LEDָʾ��1ms,���øĺ���һ��
* �������  : �� 
* ���ز���  : ��
*******************************************************************************/
static void TimerSystick10Routine(void)
{
		static uint8_t mscnt;
		static uint8_t OnOff;
		if(++mscnt>10)
		{
			mscnt=0;
			OnOff=!OnOff;
			GREEN(OnOff);
		}
}
/******************************************************************************* 
   ϵͳ�δ�ʱ���жϣ�����Ϊ1ms
*******************************************************************************/ 
void SysTick_Handler(void)
{
		static 	uint8_t Counter = 0;
						uint8_t div;
	
    if(++Counter == 100)
    {
        Counter = 0;
    }	
		UsartSystick1000Service();		
		div = Counter / 10;
    switch(Counter % 10)//10��Ƶ��10ms
    {
						case 0:  
						break;
						case 1:  
						break;
						case 2:  
						break;
						case 3: 
						break;
						case 4:          
						break; 
						case 5:             
						break;
						case 6:                                      
						break;
						case 7:                                      
						break;
						case 8: 
						break;
						case 9:
            switch(div)//�ٴ�10��Ƶ��100ms
            {							
                case 0: 							
											TimerSystick10Routine();															
								break;
                case 1:											
								break;
                default:                              
								break;
            }
            break;
    }  
} 
 

int main(void)
{
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	SysTick_Config(SystemCoreClock/1000);
	LED_GPIO_Config();
	InitializeUsart();
	printf("Enter Main .....\n");		
	while(1)
	{
		if(step<=1)
				Iap_Write();
		else if(step==2)
				Iap_load(APP_ADDR);
		else 
				Iap_load(APP2_ADDR);
	}
}


