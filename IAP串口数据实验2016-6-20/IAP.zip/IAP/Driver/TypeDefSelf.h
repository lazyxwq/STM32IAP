#ifndef __TYPE__DEF__SELF__H
#define __TYPE__DEF__SELF__H

typedef unsigned char       byte;       /*ʵ�ʲ���byte = char*/
typedef unsigned short      ushort;
typedef unsigned char       bool;

#endif
