#include "stm32f10x.h"                  // Device header

#include "SelfDebug.h"

//void (*_db_msg)(UART_ID_Type UartID, const void *s);
//void (*_db_msg_)(UART_ID_Type UartID, const void *s);
//void (*_db_char)(UART_ID_Type UartID, uint8_t ch);
//void (*_db_dec)(UART_ID_Type UartID, uint8_t decn);
//void (*_db_dec_16)(UART_ID_Type UartID, uint16_t decn);
//void (*_db_dec_32)(UART_ID_Type UartID, uint32_t decn);
//void (*_db_hex)(UART_ID_Type UartID, uint8_t hexn);
//void (*_db_hex_16)(UART_ID_Type UartID, uint16_t hexn);
//void (*_db_hex_32)(UART_ID_Type UartID, uint32_t hexn);
//void (*_db_hex_)(UART_ID_Type UartID, uint8_t hexn);
//void (*_db_hex_16_)(UART_ID_Type UartID, uint16_t hexn);
//void (*_db_hex_32_)(UART_ID_Type UartID, uint32_t hexn);

//uint8_t (*_db_get_char)(UART_ID_Type UartID);
//Bool (*_db_get_char_nonblocking)(UART_ID_Type UartID, uint8_t* c);
//uint8_t (*_db_get_val)(UART_ID_Type UartID, uint8_t option, uint8_t numCh, uint32_t * val);

/*********************************************************************//**
 * @brief       Puts a character to UART port
 * @param[in]   ch      Character to put
 * @return      None
 **********************************************************************/
void UARTPutChar (uint8_t ch)
{
    UART_Send(UartID, &ch, 1, BLOCKING);
}

/*********************************************************************//**
 * @brief       Initialize Debug frame work through initializing UART port
 * @param[in]   None
 * @return      None
 **********************************************************************/
void debug_frmwrk_init(void)
{
    UART_CFG_Type UARTConfigStruct;

		#if (USED_UART_DEBUG_PORT == 0)
				/*
				 * Initialize UART0 pin connect
				 * P0.2: TXD
				 * P0.3: RXD
				 */
//				PINSEL_ConfigPin (0, 2, 1);
//				PINSEL_ConfigPin (0, 3, 1);
		#elif (USED_UART_DEBUG_PORT == 1)

		#elif (USED_UART_DEBUG_PORT == 2)

		#elif (USED_UART_DEBUG_PORT == 3)

		#elif (USED_UART_DEBUG_PORT == 4)


		#endif

    /* Initialize UART Configuration parameter structure to default state:
     * Baudrate =115200 bps 
     * 8 data bit
     * 1 Stop bit
     * None parity
     */


//    _db_msg = UARTPuts;
//    _db_msg_ = UARTPuts_;
    _db_char = UARTPutChar;
//    _db_hex = UARTPutHex;
//    _db_hex_16 = UARTPutHex16;
//    _db_hex_32 = UARTPutHex32;
//    _db_hex_ = UARTPutHex_;
//    _db_hex_16_ = UARTPutHex16_;
//    _db_hex_32_ = UARTPutHex32_;
//    _db_dec = UARTPutDec;
//    _db_dec_16 = UARTPutDec16;
//    _db_dec_32 = UARTPutDec32;
//    _db_get_char = UARTGetChar;
//    _db_get_val = UARTGetValue;
//    _db_get_char_nonblocking = UARTGetCharInNonBlock;
}