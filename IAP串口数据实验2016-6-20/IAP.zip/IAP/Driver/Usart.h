#ifndef __USART_H_
#define __USART_H_

#include "stm32f10x.h"
#include "TypeDefSelf.h"
#define BAUDRATE			115200
#define true                1
#define false               0	
void usartConfig(void);
void putString(uint8_t * string);

#endif

