#ifndef __LED_H
#define __LED_H

#include "stm32f10x.h"

/*
*1-off
*0-on
*/
#define NO 0
#define OFF 1

#define RED(a) if(a) \
									GPIO_SetBits(GPIOB,GPIO_Pin_5);\
							 else \
								  GPIO_ResetBits(GPIOB,GPIO_Pin_5); 
#define GREEN(a) if(a) \
									GPIO_SetBits(GPIOE,GPIO_Pin_5);\
							 else \
								  GPIO_ResetBits(GPIOE,GPIO_Pin_5);

void LED_GPIO_Config(void);
							 
#endif

